export class StaticTrigger {
  public SUCCESS_STATIC: SuccessTriggers[];
  public FAILURE_STATIC: FailTriggers[];
  public SURPRESSED_STATIC: SuppressTriggers[];
}


export class SuccessTriggers {
  configId: string;
  letterName: string;
  mqName: string;
  hcType: string;
  description: string;
}

export class FailTriggers {
  configId: string;
  letterName: string;
  mqName: string;
  hcType: string;
  description: string;
}

export class SuppressTriggers {
  configId: string;
  letterName: string;
  mqName: string;
  hcType: string;
  description: string;
}
