import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { Router } from '@angular/router';
import { SpringLetterStatusService } from '../spring-letter-status.service';
import { DataSource } from '@angular/cdk/collections';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-cpu-status',
  templateUrl: './cpu-status.component.html',
  styleUrls: ['./cpu-status.component.css']
})
export class CpuStatusComponent implements OnInit {

  elementCPU: ElementCPU[] = [];

  constructor(private router: Router, private springLetterStatusService: SpringLetterStatusService) { }

  ngOnInit() {
    this.getCPUStatus();
  }

  displayedColumns = ['host', 'cpuUsage', 'memoryUsage', 'diskUsage'];
  // dataSource = new MatTableDataSource<ElementCPU>(elementCPU);
  dataSource = new MatTableDataSource();



  getCPUStatus(): void {
    this.springLetterStatusService
      .getCPUStatus().subscribe( data => {
        this.dataSource = new MatTableDataSource(data);
      });
  }


}

// const elementCPU: ElementCPU[] = [
//   {"host":"sonuat1","cpuUsage":"0.3%us,","memoryUsage":"470228k","diskUsage":"55%"},{"host":"sonuat2","cpuUsage":"0.3%us,","memoryUsage":"464112k","diskUsage":"45%"},{"host":"sonuat3","cpuUsage":"0.4%us,","memoryUsage":"484112k","diskUsage":"43%"},{"host":"sonuat4","cpuUsage":"0.3%us,","memoryUsage":"466936k","diskUsage":"42%"},{"host":"sonuat5","cpuUsage":"0.4%us,","memoryUsage":"574732k","diskUsage":"100%"},{"host":"sonuat6","cpuUsage":"0.4%us,","memoryUsage":"1100336k","diskUsage":"56%"},{"host":"sonsit1","cpuUsage":"0.4%us,","memoryUsage":"3414232k","diskUsage":"83%"},{"host":"sonsit2","cpuUsage":"0.4%us,","memoryUsage":"442712k","diskUsage":"100%"}
// ]

export interface ElementCPU {
    host: string;
    cpuUsage: string;
    memoryUsage: string;
    diskUsage: string;
    updatedTime: string;
    jBossStatus: number;
}
