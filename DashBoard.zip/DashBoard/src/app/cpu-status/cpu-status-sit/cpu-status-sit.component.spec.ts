import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CpuStatusSitComponent } from './cpu-status-sit.component';

describe('CpuStatusSitComponent', () => {
  let component: CpuStatusSitComponent;
  let fixture: ComponentFixture<CpuStatusSitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CpuStatusSitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CpuStatusSitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
