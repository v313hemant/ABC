import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cpu-status-sit',
  templateUrl: './cpu-status-sit.component.html',
  styleUrls: ['./cpu-status-sit.component.css']
})
export class CpuStatusSitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
