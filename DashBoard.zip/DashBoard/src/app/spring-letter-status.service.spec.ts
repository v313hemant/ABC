import { TestBed, inject } from '@angular/core/testing';

import { SpringLetterStatusService } from './spring-letter-status.service';

describe('SpringLetterStatusService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SpringLetterStatusService]
    });
  });

  it('should be created', inject([SpringLetterStatusService], (service: SpringLetterStatusService) => {
    expect(service).toBeTruthy();
  }));
});
