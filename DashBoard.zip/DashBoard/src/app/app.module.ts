import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SpringServicesService } from './spring-services.service';
import { AppRoutingModule } from './/app-routing.module';
import { HomeComponent } from './home/home.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatButtonModule, MatCardModule, MatMenuModule,
  MatToolbarModule,   MatIconModule, MatTableModule,
   MatInputModule, MatFormFieldModule, MatListModule } from '@angular/material';
import {MatDialogModule} from '@angular/material/dialog';
import { MatSelectModule } from '@angular/material/select'
import { LettersComponent } from './letters/letters.component';
import { MonitoringComponent } from './monitoring/monitoring.component';
import { BinderService } from './binder.service';
import { CpuStatusComponent } from './cpu-status/cpu-status.component';
import { CpuStatusSitComponent } from './cpu-status/cpu-status-sit/cpu-status-sit.component';
import { NgProgressModule } from '@ngx-progressbar/core';
import { PdfViewerModule } from 'ng2-pdf-viewer';
// import { LoadingBarRouterModule } from '@ngx-loading-bar/router';
import { LoadingBarHttpClientModule } from '@ngx-loading-bar/http-client';
import { SpringLetterStatusService } from './spring-letter-status.service';
import { PdfViewerComponent } from './pdf-viewer/pdf-viewer.component';


@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HomeComponent,
    LettersComponent,
    MonitoringComponent,
    CpuStatusComponent,
    CpuStatusSitComponent,
    PdfViewerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    BrowserModule,
    MatButtonModule,
    MatCardModule,
    MatMenuModule,
    MatToolbarModule,
    MatIconModule,
    MatTableModule,
    MatSelectModule,
    MatInputModule,
    MatFormFieldModule,
    MatListModule,
    MatDialogModule,
    BrowserAnimationsModule,
    NgProgressModule.forRoot(),
    PdfViewerModule,
    // LoadingBarRouterModule,
    LoadingBarHttpClientModule
  ],
  providers: [SpringServicesService, BinderService, SpringLetterStatusService],
  bootstrap: [AppComponent]
})
export class AppModule { }
