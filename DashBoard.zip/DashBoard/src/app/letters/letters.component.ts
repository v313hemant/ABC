import { Component, OnInit, Input, Inject } from '@angular/core';
import { Element } from '../Element';
import { StaticTrigger, SuccessTriggers, FailTriggers, SuppressTriggers } from '../StaticTrigger';
import { Router } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { BinderService } from '../binder.service';
import { NgProgress } from '@ngx-progressbar/core';
import { SpringServicesService } from '../spring-services.service';
import { SpringLetterStatusService } from '../spring-letter-status.service';

@Component({
  selector: 'app-letters',
  styleUrls: ['./letters.component.css'],
  templateUrl: './letters.component.html'
})
export class LettersComponent implements OnInit {

  pdfCreated: string;
  selectedEventID: string;
  element: Element;
  staticTrigger: StaticTrigger;
  SUCCESS_STATIC: SuccessTriggers[];
  FAILURE_STATIC: FailTriggers[];
  SURPRESSED_STATIC: SuppressTriggers[];
  pdfPath: string;
  selected= 'DIT1';

  error: any;

  @Input()
  textValue: string;

  triggerTypes = [
      {value: 'UAT', viewValue: 'UAT'},
      {value: 'SIT', viewValue: 'SIT'},
      {value: 'DIT1', viewValue: 'DIT'}
  ];

  constructor(private binderService: BinderService,
    private router: Router, public progress: NgProgress,
    private springServicesService: SpringServicesService,
    private springLetterStatusService: SpringLetterStatusService) { }

  ngOnInit(){
    this.pdfCreated='12312321';
    this.getElement();
    this.getListOfStaticTriggers(this.element.letterName);
    this.textValue = "Insert Custom Trigger Here..........";
  }
  onClickChangeEnv(env: string) {
    console.log(this.selected);
    // const link = ['/letters/',env];
    // this.router.navigate(link);
  }

  onCLickEventId(eventId: string) {
    console.log('Run ConfigId: ',eventId);
    this.selectedEventID=eventId;
    this.springLetterStatusService
      .runStaticConfigId(eventId)
        .then(pdfPath => {
          this.pdfPath=pdfPath;
          this.progress.complete();
          this.pdfCreated=eventId;
        });
  }

  onClickShowPDF(eventId: string) {
    if(this.selectedEventID===eventId){
      console.log('pdfPath ',this.pdfPath);
      const link = ['/letters/PDF', {pdfPath: this.pdfPath}];
      this.router.navigate(link);
    }
  }

  getElement() {
    this.binderService.currentElement.subscribe(elementLetter => {
      this.element = elementLetter
    }, err => {
      console.log(err);
    });
  }

  getListOfStaticTriggers(letterName: string): void {
    this.springServicesService
      .getListOfStaticTrigger(letterName)
      .then(staticTrigger => {
        this.SUCCESS_STATIC = staticTrigger.SUCCESS_STATIC;
        this.FAILURE_STATIC = staticTrigger.FAILURE_STATIC;
        this.SURPRESSED_STATIC = staticTrigger.SURPRESSED_STATIC;
        });
      ;
  }

}
