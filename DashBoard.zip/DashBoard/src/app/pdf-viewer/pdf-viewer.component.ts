import { Component, OnInit } from '@angular/core';
import { ActivatedRoute }     from '@angular/router';
import 'rxjs/add/operator/filter';

@Component({
  selector: 'app-pdf-viewer',
  // template: `
  //   <pdf-viewer src=""></pdf-viewer>
  // `
  templateUrl: './pdf-viewer.component.html',
  styleUrls: ['./pdf-viewer.component.css']
})
export class PdfViewerComponent implements OnInit {

  constructor(private route: ActivatedRoute) { }

  pdfPath: string;

  ngOnInit() {
    this.route
    .queryParams
    .filter(params => params.pdfPath)
    .subscribe(params => {
        this.pdfPath=params.pdfPath;
    });
    // this.pdfPath = "../../../assets/atv.pdf";
  }

}
