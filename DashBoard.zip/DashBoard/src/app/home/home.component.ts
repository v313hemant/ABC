import { Component, OnInit, Input, EventEmitter } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { Router } from '@angular/router';
import { Element } from '../Element';
import { ElementEODHC } from '../ElementEODHC';
import { BinderService } from '../binder.service';
import { SpringLetterStatusService } from '../spring-letter-status.service';
import { DataSource } from '@angular/cdk/collections';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

@Component({
  selector: 'app-home',
  styleUrls: ['./home.component.css'],
  templateUrl: './home.component.html'
})

  export class HomeComponent implements OnInit {

    elements: Element[] = [];
    elementsStaticData: Element[] = [];
    elementsEODHC: ElementEODHC[] = [];
    error: any;
    selected= 'UAT';

    triggerTypes = [
        {value: 'UAT', viewValue: 'UAT'},
        {value: 'SIT', viewValue: 'SIT'},
        {value: 'DIT1', viewValue: 'DIT'}
    ];
    statusTypes = [
        {value: 'typeStatic', viewValue: 'Start HC'},
        {value: 'typeRealtime', viewValue: 'Start Testing Suite'}
    ];

    displayedColumns = ['letterName', 'passCount', 'failCount', 'suppressedCount'];
    dataSource = new MatTableDataSource();
    //StaticData table
    displayedColumns2 = ['letterName', 'passCount', 'failCount', 'suppressedCount'];
    dataSource2 = new MatTableDataSource();
    //EOD table
    displayedColumns1 = ['environment', 'triggerStatus', 'SCVFlagReceived', 'ArchivalCompleted', 'CoEodCompleted'];
    dataSource1 = new MatTableDataSource();

    constructor(private router: Router,
    private binderService: BinderService,
    private springLetterStatusService: SpringLetterStatusService) { }

    ngOnInit(): void {
      this.initializeComponent();
    }
    private initializeComponent() {
      this.getElement(this.selected);
      this.getElementStaticData(this.selected);
      this.getElementEODHC();
    }
    getElement(env: string): void {
      this.springLetterStatusService
        .getElements(env).then( data => {
          this.dataSource = new MatTableDataSource(data);
        }, data => this.elements = data.data );
    }

    getElementStaticData(env: string): void {
      this.springLetterStatusService
        .getElementsStaticData(env).then( data => {
          this.dataSource2 = new MatTableDataSource(data);
        }, data => this.elementsStaticData = data.data );
    }

    getElementEODHC(): void {
      this.springLetterStatusService
        .getElementsEODHC().subscribe( data => {
          this.dataSource1 = new MatTableDataSource(data);
        }, data => this.dataSource1 = new MatTableDataSource(data));
    }

    onClickLetterName(element: Element): void {
      this.binderService.setElement(element);
      const link = ['/letters'];
      this.router.navigate(link);
    }

    onClickChangeEnv(env: string) {
      this.springLetterStatusService
        .setEnv(env);
      this.initializeComponent();
    }

    onClickChangeType(type: string) {
      const link = ['/StatusType/',type];
      this.router.navigate(link);
    }

    masterToggle() {
        if (!this.dataSource) {
          return;
        }
    }

  }

  /** Constants used to fill up our data base. */
const COLORS = ['maroon', 'red', 'orange', 'yellow', 'olive', 'green', 'purple',
  'fuchsia', 'lime', 'teal', 'aqua', 'blue', 'navy', 'black', 'gray'];
const NAMES = ['Maia', 'Asher', 'Olivia', 'Atticus', 'Amelia', 'Jack',
  'Charlotte', 'Theodore', 'Isla', 'Oliver', 'Isabella', 'Jasper',
  'Cora', 'Levi', 'Violet', 'Arthur', 'Mia', 'Thomas', 'Elizabeth'];

// const ELEMENT_DATA: Element[] = [
// {letterName: 'AFEES_MO', passCount: 20, failCount: 1, suppressedCount: 0 },
// {letterName: 'SNV', passCount: 25, failCount: 3, suppressedCount: 1},
// {letterName: 'COCD', passCount: 6, failCount: 4, suppressedCount: 0},
// {letterName: 'COT', passCount: 9, failCount: 1, suppressedCount: 2},
// {letterName: 'DSC', passCount: 10, failCount: 7, suppressedCount: 1},
// {letterName: 'CSH', passCount: 12, failCount: 2, suppressedCount: 1},
// {letterName: 'ADA', passCount: 14, failCount: 3, suppressedCount: 2},
// {letterName: 'SOCL', passCount: 15, failCount: 0, suppressedCount: 3},
// {letterName: 'RPOU', passCount: 50, failCount: 10, suppressedCount: 1},
// {letterName: 'CA', passCount: 20, failCount: 2, suppressedCount: 2},
// ];
