import { Injectable } from '@angular/core';
import { Headers, Http, Response } from '@angular/http';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/toPromise';
import { Observable }   from 'rxjs/Observable';
import { Element } from './Element';
import { ElementEODHC } from './ElementEODHC';
import { catchError } from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';

@Injectable()
export class SpringLetterStatusService {

  private elementStaticDataUrl = "hcSuite/triggersFinalStatusCount";
  private elementRealtimeDataUrl = "hcSuite/triggersFinalStatusCount";
  private elementEODDataUrl = "hcSuite/checkEODStatus";
  private elementCPUUrl = "hcSuite/getCpuStatus";
  private runSelectedTriggerURL = "hcSuite/home";
  private currentEnv = "DIT1";
  private currentConfigId: string;
  elementCPU: ElementCPU[] = [];

  constructor(private http: Http, private _HttpClient: HttpClient) { }

  setEnv(env: string) {
    this.currentEnv = env;
  }

  runStaticConfigId(configId: string): Promise<string> {
    this.currentConfigId = configId;
    let params = new HttpParams().set('configId', this.currentConfigId);
    let headers = new HttpHeaders().set('Accept', 'text/plain, application/json, */*');

    return this._HttpClient.get(this.runSelectedTriggerURL, { headers: headers,responseType: 'text', params: params }).toPromise()
      .then((response) => {
        return response as string;
      } )
      .catch(this.handleError);
  }

  getElements(env: string): Promise<Array<Element>> {
    this.currentEnv = env;
    let params = new HttpParams().set('env', this.currentEnv);

    return this._HttpClient.get(this.elementStaticDataUrl, { params: params }).toPromise()
      .then((response) => {
        return response as Element[];
      } )
      .catch(this.handleError);
  }

  getElementsStaticData(env: string): Promise<Array<Element>> {
    this.currentEnv = env;
    let params = new HttpParams().set('env', this.currentEnv);

    return this._HttpClient.get(this.elementRealtimeDataUrl, { params: params }).toPromise()
      .then((response) => {
        return response as Element[];
      } )
      .catch(this.handleError);
  }

  getElementsEODHC(): Observable<Array<ElementEODHC>> {
      return this.http.get(this.elementEODDataUrl)
        .map(response => { return response.json() });
  }

  // getElementsStaticData(): Observable<Array<Element>> {
  //   return this.http.get(this.elementRealtimeDataUrl)
  //     .map(response => { return response.json() });
  // }

  getCPUStatus(): Observable<ElementCPU[]> {
    return this. http.get(this.elementCPUUrl)
      .map(response => { return response.json() as ElementCPU[] });
  }

  private handleError(error: any): Promise<any> {
      console.error('An error occurred', error);
      return Promise.reject(error.message || error);
    }

}

export interface ElementCPU {
    host: string;
    cpuUsage: string;
    memoryUsage: string;
    diskUsage: string;
    updatedTime: string;
    jBossStatus: number;
}
