import { TestBed, inject } from '@angular/core/testing';

import { SpringServicesService } from './spring-services.service';

describe('SpringServicesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SpringServicesService]
    });
  });

  it('should be created', inject([SpringServicesService], (service: SpringServicesService) => {
    expect(service).toBeTruthy();
  }));
});
