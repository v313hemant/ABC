import { Injectable } from '@angular/core';
import { Headers, Http, Response } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Mqueue } from './Mqueue';
import { WebService } from './WebService';
import { StaticTrigger } from './StaticTrigger';
import { Observable }   from 'rxjs/Observable';

@Injectable()
export class SpringServicesService {

  private webServiceUrl = "/hcSuite/serviceStatus";
  private mqStatusUrl = "/hcSuite/checkQueueStatus";
  private listOfStaticTriggerUrl = "/hcSuite/staicTriggers";
  private currentEnv = "DIT1";
  constructor(private http: Http, private _HttpClient: HttpClient) { }

  setEnv(env: string) {
    this.currentEnv = env;
  }

  getWebServices(env: string): Promise<Array<WebService>> {
    this.currentEnv = env;
    let params = new HttpParams().set('env', this.currentEnv);

    return this._HttpClient.get(this.webServiceUrl, { params: params }).toPromise()
      .then((response) => {
        return response as WebService[];
      } )
      .catch(this.handleError);
  }

  getMqStatus(env: string): Promise<Array<Mqueue>> {
    this.currentEnv = env;
    let params = new HttpParams().set('env', this.currentEnv);

    return this._HttpClient.get(this.mqStatusUrl, { params: params }).toPromise()
      .then((response) => {
        return response as Mqueue[];
      } )
      .catch(this.handleError);
  }

  getListOfStaticTrigger(letterName: string): Promise<StaticTrigger>{

    let params = new HttpParams().set('letterName', letterName);
    // return this._HttpClient.get(webServiceUrl, { params: params });

    return this._HttpClient.get(this.listOfStaticTriggerUrl, { params: params }).toPromise()
      .then((response) => {
        return response as StaticTrigger;
      } )
      .catch(this.handleError);

  }

  private handleError(error: any): Promise<any> {
      console.error('An error occurred', error);
      return Promise.reject(error.message || error);
    }

}
