export class WebService {
  webServiceURL: string;
  status: string;
}
