import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Mqueue } from '../Mqueue';
import { WebService } from '../WebService';
import { SpringServicesService } from '../spring-services.service';
import { ActivatedRoute }     from '@angular/router';
import 'rxjs/add/operator/filter';

@Component({
  selector: 'app-monitoring',
  templateUrl: './monitoring.component.html',
  styleUrls: ['./monitoring.component.css']
})
export class MonitoringComponent implements OnInit {

    mqOrWebServiceFlag: string;
    monitoringTitle: string;
    mqueues: Mqueue[] = [];
    webServices: WebService[] = [];
    selectedElement: Mqueue;
    error: any;
    triggerTypes = [
        {value: 'UAT', viewValue: 'UAT'},
        {value: 'SIT', viewValue: 'SIT'},
        {value: 'DIT1', viewValue: 'DIT'}
    ];

    selected= 'UAT';

    constructor(private router: Router,private springServicesService: SpringServicesService,
                private route: ActivatedRoute) { }

    ngOnInit(): void {
      this.route
      .queryParams
      .filter(params => params.varWhichComp)
      .subscribe(params => {
          this.mqOrWebServiceFlag=params.varWhichComp;
          this.initializeComponent();
      });
    }

    private initializeComponent() {
      if(this.mqOrWebServiceFlag==="mq"){
          this.getMqueueStatus(this.selected);
          this.monitoringTitle = "Context Status";
      }else{
          this.getWebServicesStatus(this.selected);
          this.monitoringTitle = "Web Services Status";
      }
    }

    getColor(status) {
      switch (status) {
        case '1':
          return '#00D778';
          case '0':
          return '#ce2002';
      }
    }

    getWebServicesStatus(env: string): void {
      this.springServicesService
        .getWebServices(env)
        .then(webServices => this.webServices = webServices)
        .catch(error => this.error = error);
    }

    getMqueueStatus(env: string): void {
      this.springServicesService
        .getMqStatus(env)
        .then(mqueues => this.mqueues = mqueues)
        .catch(error => this.error = error);
    }

    refreshIt(mqueue: Mqueue): void{
      this.selectedElement = mqueue;
    }

    onSelect(mqueue: Mqueue): void {
      this.selectedElement = mqueue;
    }

    onClickChangeEnv(env: string) {
      this.springServicesService
        .setEnv(env);
      this.selected = env;
      //Need to add abort service code
      this.initializeComponent();

    }

}
