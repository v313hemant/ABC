import { Injectable } from '@angular/core';
// import { Subject }    from 'rxjs/Subject';
import { Element } from './Element';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
@Injectable()
export class BinderService {

  private home_letters_element = new BehaviorSubject<Element>(null);
  currentElement = this.home_letters_element.asObservable();

  constructor() { }

  setElement(element: Element) {
    this.home_letters_element.next(element);
  }

}
