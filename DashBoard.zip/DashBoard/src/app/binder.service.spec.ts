import { TestBed, inject } from '@angular/core/testing';

import { BinderService } from './binder.service';

describe('BinderService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BinderService]
    });
  });

  it('should be created', inject([BinderService], (service: BinderService) => {
    expect(service).toBeTruthy();
  }));
});
