export class EnvModel {

  envName: string;
  right: string;

}
