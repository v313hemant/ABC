import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { LettersComponent } from './letters/letters.component';
import { MonitoringComponent } from './monitoring/monitoring.component';
import { PdfViewerComponent } from './pdf-viewer/pdf-viewer.component';
const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'TestingSuite', component: DashboardComponent },
  { path: 'Environment', component: DashboardComponent },
  { path: 'home/home', component: HomeComponent },
  { path: 'letters', component: LettersComponent },
  { path: 'letters/PDF', component: PdfViewerComponent },
  { path: 'monitoring', component: MonitoringComponent}
  // { path: 'detail/:id', component: HeroDetailComponent },
  // { path: 'heroes', component: HeroesComponent }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
