import { Component } from '@angular/core';

// <mat-icon>home</mat-icon>

@Component({
  selector: 'my-root',
  template: `
    <mat-toolbar color="primary">
    <nav> <a routerLink="/dashboard" routerLinkActive="active"> <i class="material-icons">home <span>{{title}}</span></i> </a></nav>
      <span class="example-fill-remaining-space"></span>
      <nav>
        <a routerLink="/TestingSuite" routerLinkActive="active">Testing Suite Status</a>
        <a routerLink="/monitoring" [queryParams]="{varWhichComp: 'mq'}" routerLinkActive="active">Context Status</a>
        <a routerLink="/monitoring" [queryParams]="{varWhichComp: 'webService'}" routerLinkActive="active">Web Services Status</a>
      </nav>
    </mat-toolbar>
    <router-outlet></router-outlet>
    <ngx-loading-bar></ngx-loading-bar>
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Customer Output HC Dashboard';
}
