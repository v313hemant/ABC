export class ElementEODHC {
  environment : string;
  triggerStatus: string;
  SCVFlagReceived: string;
  ArchivalCompleted: string;
  CoEodCompleted: string;
}
