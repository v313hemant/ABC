export class Mqueue {
  queue_name: string;
  status: string;
}
