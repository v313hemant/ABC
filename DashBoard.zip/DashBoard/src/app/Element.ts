export class Element {
  letterName : string;
  passCount: number;
  failCount: number;
  suppressedCount: number;
}
